const user=require('../Model/users.js');
exports.getProfile=email=>
	new Promise((resolve,reject)=>{
		user.aggregate([{$project:{_id:0,nume:1,prenume:1,email:1,created_at:{$substr:["$created_at",0,10]}}},{$match:{email:email}}])
		.then(users=>resolve(users[0]))
		.catch(err=>reject({status:500,message:'server error'}))
	});



	
	 