const user=require('../Model/users.js');
exports.getName=email=>
	new Promise((resolve,reject)=>{
		user.find({email:email},{prenume:1,_id:0})
		.then(users=>resolve(users[0]))
		.catch(err=>reject({status:500,message:'server error'}))
	});

