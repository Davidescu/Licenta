const user=require('../Model/users.js');
const bcrypt=require('bcryptjs');
const nodeMailer=require('nodemailer');
const randomString=require("randomstring");
exports.changePassword=(email, password,newPassword)=>
	new Promise((resolve,reject)=>{

		user.find({email:email})

		.then(users=>{
			let user=users[0];
			const hashed_password=user.password;

			if(bcrypt.compareSync(password,hashed_password)){
				const salt=bcrypt.genSaltSync(10);
				const hash=bcrypt.hashSync(newPassword,salt);
				user.password=hash;
				return user.save();
			}
			else
			{
				reject({status:401,
				message:'Parola veche este incorecta!'});
			}
		})
		.then(user=>resolve({status:200,message:'Parola a fost actualizata cu succes!'}))
		.catch(err=>reject({status:500,message:'Server error!'}));
	});
exports.resetPasswordInit=email=>
	new Promise((resolve,reject)=>{
		const random = randomString.generate(8);

		user.find({ email: email })

		.then(users => {

			if (users.length == 0) {

				reject({ status: 404, message: 'User Not Found !' });

			} else {

				let user = users[0];
				const salt = bcrypt.genSaltSync(10);
				const hash = bcrypt.hashSync(random, salt);
				user.temp_pass = hash;
				user.temp_password_time = new Date();
				return user.save();
			}
		})
		.then(user=>{
			process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
			const transporter=nodeMailer.createTransport({
				service:'gmail',
				auth:{
				  user:'dumitru.daniel.davidescu@gmail.com',
				  pass:'Daviddany18'
				}
			  
				});
				const mailOption={
				from:'dumitru.daniel.davidescu@gmail.com',
				to:email,
				subject:'Reset Password',
				html:`Bună ${user.nume}. Parola dumneavoastră este ${random} . Aceasta este valabila 2 minute`
				};
				return transporter.sendMail(mailOption);
		})

		.then(info=>{
			console.log(info);
			resolve({ status: 200, message: 'Verificati email-ul pentru validare!' })
		})
		.catch(err=>{
			console.log(err);
			reject({ status: 500, message: 'Internal Server Error !' });
		})
	});


exports.resetPasswordFinish=(email,token,password)=>
	new Promise((resolve,reject)=>{
		user.find({email:email})
		.then(users=>{
			let user=users[0];
			const diff = new Date() - new Date(user.temp_password_time); 
			const seconds = Math.floor(diff / 1000);
			console.log(`Seconds : ${seconds}`);

			if (seconds < 300) {

				if (bcrypt.compareSync(token, user.temp_pass)) {

					const salt = bcrypt.genSaltSync(10);
					const hash = bcrypt.hashSync(password, salt);
					user.password = hash;
					user.temp_pass = undefined;
					user.temp_password_time = undefined;
	
					return user.save();
	
				} else {
	
					reject({ status: 401, message: 'Token invalid !' });
				}
				

			} else {

				reject({ status: 401, message: 'Timpul a expirat!' });
			}
			
		})

		.then(user => resolve({ status: 200, message: 'Parola a fost schimbata cu succes!' }))

		.catch(err => reject({ status: 500, message: 'Internal Server Error !' }));
	});