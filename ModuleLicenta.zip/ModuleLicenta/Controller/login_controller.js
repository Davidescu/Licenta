const user=require('../Model/users.js');
const bcrypt=require('bcryptjs');


exports.loginUser=(email,password)=>
	new Promise((resolve,reject)=>{
		user.find({email:email})
		.then(users=>{
			if(users.length==0){
				reject({status:404,message:'User not found!'});
			}
			else
			{
				return users[0];
			}
		})
		.then (user=>{
			const hash_password=user.password;
			if(bcrypt.compareSync(password,hash_password)){
				resolve({email});
			}
			else
			{
				reject({status:401,message:'Invalid!'});

			}
		})
		.catch(err=>reject({status:500,message:'Server error!'}));
	});