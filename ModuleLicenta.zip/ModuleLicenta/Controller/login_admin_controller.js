const admin=require('../Model/admins.js');
const bcrypt=require('bcryptjs');


exports.loginAdmin=(nume,password)=>
	new Promise((resolve,reject)=>{
		admin.find({nume:nume})
		.then(admins=>{
			if(admins.length==0){
				reject({status:404,message:'User not found!'});
			}
			else
			{
				return admins[0];
			}
		})
		.then (admin=>{
			const hash_password=admin.password;
			if(bcrypt.compareSync(password,hash_password)){
				resolve({nume});
			}
			else
			{
				reject({status:401,message:'Invalid!'});

			}
		})
		.catch(err=>reject({status:500,message:'Server error!'}));
	});