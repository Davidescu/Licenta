const user=require('../Model/users.js');
const bcrypt=require('bcryptjs');
exports.registerUser=(nume,prenume,email, password)=>
	new Promise((resolve,reject)=>{
		const salt=bcrypt.genSaltSync(8);
		const hash=bcrypt.hashSync(password,salt);
		const newUser=new user({
			nume:nume,
			prenume:prenume,
			email:email,
			password:hash,
			created_at:new Date()
		});
		newUser.save()
		.then(()=>resolve({status:201,message:'Înregistrare cu succes!'}))
		.catch(err=>{
			if(err.code==11000){
				reject({status:409,message:'Utilizatorul există deja!'});
			}
			else
			{
				reject({status:500,message:'Server error!'});
			}
		});
	});