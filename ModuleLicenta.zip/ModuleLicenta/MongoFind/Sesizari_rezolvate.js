const sesizari=require('./Model/date_sesizari.js');

exports.Sesizari_Rezolvate=email=>
	new Promise((resolve,reject)=>{
		sesizari.find({status:'Rezolvat'})
		.then(getSesizari=>resolve(getSesizari))
		.catch(err=>reject({status:500,message:'server error'}))
	});

