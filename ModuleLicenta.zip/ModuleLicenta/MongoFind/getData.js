//const sesizari=require('./Model/date_sesizari.js');
//const sesizari=require('./Photo/photo.js');
exports.getData=email=>
	new Promise((resolve,reject)=>{
		sesizari.find({'metadata.email':email},{'metadata.email':1,'metadata.categorie':1,'metadata.street':1,'metadata.descriere':1,'metadata.status':1,_id:0})
		.then(sendingsesizari=>resolve(sendingsesizari))
		.catch(err=>reject({status:500,message:'server error'}))
	});

