const sesizari=require('./Model/date_sesizari.js');
const photo=require('./Photo/Photo.js');

exports.getSesizari=email=>
	new Promise((resolve,reject)=>{
		sesizari.find()
		.then(getSesizari=>resolve(getSesizari))
		.catch(err=>reject({status:500,message:'server error'}))
	});

