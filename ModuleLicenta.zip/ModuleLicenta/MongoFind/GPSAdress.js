const mongodb=require('mongodb');
const ObjectID=mongodb.ObjectID;
const MongoClient=mongodb.MongoClient;
const user=require('./Model/users.js');


module.exports=app =>{


//Connection URL
const url='mongodb://localhost:27017/'
MongoClient.connect(url,{useNewUrlParser:true},function(err,client){
	if (err)
		console.log('Unable to connect to the MongoDB server', err);
	else{

		
		app.get('/user', (req, res) => {
			const db=client.db('Sesizari_Database')
  		db.collection('users').find().toArray((err, result) => {
   			 if (err) return console.log(err);
		res.send(result);
		//res.send("Hello world!");
    	console.log("get ok");
 	 });
	});

			app.post('/gpsCoord',(request,response,next)=>{
						const post_data=request.body;
						const latitude=post_data.latitude;
						const longitude=post_data.longitudel;
						const insertJson={
							'latitude':latitude,
							'longitude':longitude,
							
							
						};
						const db=client.db('Sesizari_Database')
								//Insert data
								db.collection('GPSCoordonation')
									.insertOne(insertJson,function(error,res){
										response.json('GPS coordonation insertJson');
										console.log('GPS coordonation insertJson');
									})


						});

					app.post('/gpsAddress',(request,response,next)=>{
						const post_data=request.body;
						const street=post_data.street;
						const insertJson={
							'street':street,
							
							
							
							
						};
						const db=client.db('Sesizari_Database')
								//Insert data
								db.collection('gpsAddress')
									.insertOne(insertJson,function(error,res){
										response.json('GPS address insertJson');
										console.log('GPS address insertJson');
									})


						});
				}
			})
			}

		