const sesizari=require('./Model/date_sesizari.js');
exports.getStatus=email=>
	new Promise((resolve,reject)=>{
		sesizari.find({email:email},{status:1,_id:0})
		.then(sendingsesizari=>resolve(sendingsesizari))
		.catch(err=>reject({status:500,message:'server error'}))
	});
