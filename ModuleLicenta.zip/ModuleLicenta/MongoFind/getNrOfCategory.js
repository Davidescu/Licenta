const sesizari=require('./Model/date_sesizari.js');
exports.getNrOfCategory=email=>
	new Promise((resolve,reject)=>{
		sesizari.aggregate({'$group':{'_id':{'categorie':"$categorie"},'count':{'$sum':1}}})
		.then(sendingsesizari=>resolve(sendingsesizari))
		.catch(err=>reject({status:500,message:'server error'}))
	});

