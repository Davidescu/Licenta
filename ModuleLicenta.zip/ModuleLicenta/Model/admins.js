const mongoose=require('mongoose');
const Schema=mongoose.Schema;

const userSchema=mongoose.Schema({
	nume : String,
	prenume: String,
	email : {type:String,unique:true},
	password :String,
	created_at:String,
	temp_pass :String,
	temp_password_time:String
});
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/Sesizari_Database');

module.exports = mongoose.model('Admins', userSchema);  