const express = require('express');
const router=express.Router();
const bodyParser=require('body-Parser');
const logger 	   = require('morgan');//pentru format
const sessions=require('express-session');
const cookieParser = require('cookie-parser');
const loginAdmin=require('./Controller/login_admin_controller.js');



    router.use(bodyParser.json());
    router.use(bodyParser.urlencoded({extended:true}));


    router.use(logger('dev'));
    router.use(cookieParser());
    router.use(sessions({
        key: 'user_sid',
        secret: 'DanielLicenta',
        resave: false,
        saveUninitialized: false,
        cookie: {
            expires: 600000000
        }
        
    }));

    
    let session;
    let sessionChecker = (req, res, next) => {
        if (req.session.uniqueID && req.cookies.user_sid) {
            res.redirect('/home');
        } else {
            next();
        }    
    };
    
 
    router.get('/',sessionChecker, (req, res) => {
    
      res.sendFile(__dirname + '/HTML/index.html');
        
    });
    router.get('/sesizari',(req,res)=>{
      session=req.session;
      if(session.uniqueID)
      {
        res.sendFile(__dirname+'/HTML/sesizari.html');
      }
      else
      {
        res.redirect('/');
      }
      
    });
  
    router.get('/statistici',(req,res)=>{
      session=req.session;
      if(session.uniqueID)
      {
        res.sendFile(__dirname+'/HTML/statistici.html');
      }
      else
      {
        res.redirect('/');
      }
      
    });
    
    router.get('/sesizari_noi',(req,res)=>{
      session=req.session;
      if(session.uniqueID)
      {
        res.sendFile(__dirname+'/HTML/sesizari_noi.html');
      }
      else
      {
        res.redirect('/');
      }
      
    });
    
  
    
    router.get('/login', (req, res) => {
        session=req.session;
        if(!session.uniqueID)
        {
          res.sendFile(__dirname + '/HTML/login.html');
        }
    
    });

    router.post('/loginWeb', function(req, res) {
      
      session=req.session;
      if(session.uniqueID)
      {
        res.redirect('/home')
      }
      const username=req.body.username;
      const password=req.body.password;
      loginAdmin.loginAdmin(username,password)
			.then(result=>{
        session.uniqueID=req.body.username;
        console.log(session.uniqueID);
        res.redirect('/home');
        		
			})
      .catch(err=>res.redirect('/login'));
              
      //res.redirect('/home');
     // res.redirect('/');
    

  });
  
  router.get('/home', (req, res) => {
   
    session=req.session;
    if(session.uniqueID)
    {
      res.sendFile(__dirname + '/HTML/home.html');
    }
    else
    {
      res.redirect('/');
    }
   
  });

  router.get('/logout',(req,res) => {
    session.destroy((err) => {
        if(err) {
            return console.log(err);
        }
  
        res.redirect('/');
    });
  });


module.exports = router;