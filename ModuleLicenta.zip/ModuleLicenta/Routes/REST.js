
const bodyParser = require('body-parser');
const jwt=require('jsonwebtoken');
const express = require('express');
const register=require('../Controller/register_controller.js');
const login=require('../Controller/login_controller.js');
const password=require('../Controller/changePassword_controller.js');
const profile=require('../Controller/profile_controller.js');
const config=require('../config.json');
const user=require('../Model/users.js');
const name=require('../Controller/getName_controller.js');
const checkAuth=require('../check-auth.js');


const router=express.Router();

	router.post('/register',(request,res)=>{
		const post_data=request.body;
		const nume=post_data.nume;
		const prenume=post_data.prenume;
		const email=post_data.email;
		const password=post_data.password;
		
		if(!nume||!prenume||!email||!password){
			res.status(400).json({message:'Invalid request!'});

		}
		else
		{
			register.registerUser(nume,prenume,email,password)
			.then(result=>{
				res.status(result.status).json({message:result.message})
			})
			.catch(err=>res.status(err.status).json({message:err.message}));
		}

	});
	router.post('/login',(request,response)=>{
		
			const post_data=request.body;
			const email=post_data.email;
			const password=post_data.password;
			
		
			login.loginUser(email,password)
			.then(result=>{
				
				const token=jwt.sign(result,config.secret,{expiresIn:"10h"});
				response.json({message:result,token:token});
				
			
			})
			.catch(err=>response.status(err.status).json({message:err.message}));
	
		
	});

	router.put('/changePassword',checkAuth,(req,res)=>{
		
			const oldPassword=req.body.password;
			const newPassword=req.body.newPassword;
			if (!oldPassword || !newPassword || !oldPassword.trim() || !newPassword.trim()) {

				res.status(400).json({ message: 'Invalid Request !' });

			} else {

				password.changePassword(req.body.email, oldPassword, newPassword)

				.then(result => res.status(result.status).json({ message: result.message }))

				.catch(err => res.status(err.status).json({ message: err.message }));

			}
	});
	router.post('/users/resetPassword/', (req,res) => {

		const email = req.body.email;
		const token = req.body.token;
		const newPassword = req.body.password;

		if (!token || !newPassword || !token.trim() || !newPassword.trim()) {

			password.resetPasswordInit(email)
			.then(result => res.status(result.status).json({ message: result.message }))
			.catch(err => res.status(err.status).json({ message: err.message }));

		} else {

			password.resetPasswordFinish(email, token, newPassword)
			.then(result => res.status(result.status).json({ message: result.message }))
			.catch(err => res.status(err.status).json({ message: err.message }));
		}
	});


	router.get('/getNrUsers',(req,res)=>{
		user.count({},function(error,nr){
			if(error) throw error;
			count=nr;
			res.json({"User":count});
		});
	});
	router.get('/users/:email',(req,res) => {
		name.getName(req.params.email)
		.then(result => {				
			res.json(result)})
		.catch(err => res.status(err.status).json({ message: err.message }));


	});
	router.get('/profile/:email',checkAuth, (req,res) => {
		
				profile.getProfile(req.params.email)
				.then(result => {
					res.json(result)})
				.catch(err => res.status(err.status).json({ message: err.message }));
	});
	
	
	
module.exports = router;
	
		
		
