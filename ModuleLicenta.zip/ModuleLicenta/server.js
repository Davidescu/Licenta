const express=require('express');
const app=express();
const bodyParser=require('body-Parser');
const logger= require('morgan');
const cookieParser = require('cookie-parser');
const cors=require('cors'); 


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(cors());
app.use(logger('dev'));
app.use(cookieParser());
app.use(express.static(__dirname+'/Javascript'));
app.use(express.static(__dirname+'/CSS'));
app.use(express.static(__dirname+'/Imagini'));



const router=require('./Routes/REST');
app.use('/',router);

require('./Photo/Photo.js')(app);

const routes = require('./route');
app.use('/', routes);





const server=app.listen(3000,()=>{
	console.log('Server run PORT 3000');
});