$.ajax({
    url: 'http://localhost:3000/sesizariRezolvate',
    dataType:'json',
    success: function(data) {
      var nr=data.Numar;
      document.getElementById("sesizari_rezolvate").innerHTML=nr;
    }
  });
  $.ajax({
    url: 'http://localhost:3000/getNrUsers',
    dataType:'json',
    success: function(data) {
      var nr=data.User;
      document.getElementById("nr_user").innerHTML=nr;
    }
  });
  $.ajax({
    url: 'http://localhost:3000/sesizariNerezolvate',
    dataType:'json',
    success: function(data) {
      var nr=data.Numar;
      document.getElementById("sesizari_nerezolvate").innerHTML=nr;
    }
  });



  function DashboardCategoriiSesizari() {
      let dropdown,filter;
      dropdown = document.getElementById("nrSesizariDupaStatus");
      filter=dropdown.value;
    $(document).ready(function(){
      $.ajax({
        url: 'http://127.0.0.1:3000/NrOfCategoryByStatus/'+filter,
        dataType: 'json',
        credentials: "same-origin", 
        headers: {
                'Access-Control-Allow-Origin': '*',
              },
        success: function(data) {
            document.getElementById("transport_in_comun").innerHTML=0;
                document.getElementById("politie").innerHTML=0;
                document.getElementById("dotari_urbane").innerHTML=0;
                document.getElementById("scoli").innerHTML=0;
                document.getElementById("spitale").innerHTML=0;
                document.getElementById("spitale").innerHTML=0;
                document.getElementById("caini_fara_stapan").innerHTML=0;
                document.getElementById("parcuri").innerHTML=0;
                document.getElementById("iluminat_public").innerHTML=0;
            for (var i=0; i<data.length; i++)
            {
                //var nr=data[i].count;
                
                
                if(data[i]._id.categorie=="Transport")
                {
                    var nr=data[i].count;
                    document.getElementById("transport_in_comun").innerHTML=nr;
                }
               
            
                if(data[i]._id.categorie=="Politie")
                {
                    var nr=data[i].count;
                    document.getElementById("politie").innerHTML=nr;
                }
               
                if(data[i]._id.categorie=="Mobilier")
                {
                    var nr=data[i].count;
                    document.getElementById("dotari_urbane").innerHTML=nr;
                }
                
                if(data[i]._id.categorie=="Scoala")
                {
                    var nr=data[i].count;
                    document.getElementById("scoli").innerHTML=nr;
                }
                
                if(data[i]._id.categorie=="Spital")
                {
                    var nr=data[i].count;
                    document.getElementById("spitale").innerHTML=nr;
                }
               
                if(data[i]._id.categorie=="Caini")
                {
                    var nr=data[i].count;
                    document.getElementById("caini_fara_stapan").innerHTML=nr;
                }
               
                if(data[i]._id.categorie=="Parcuri")
                {
                    var nr=data[i].count;
                    document.getElementById("parcuri").innerHTML=nr;
                }
               
                if(data[i]._id.categorie=="Iluminat")
                {
                    var nr=data[i].count;
                    document.getElementById("iluminat_public").innerHTML=nr;
                }
                
               
                
            }
           
        }
        });
    });
  
}
          