google.charts.load("current", {packages:["corechart"]});
google.charts.setOnLoadCallback(drawChart);
function drawChart() {

    $(document).ready(function(){
        $.ajax({
            url: "http://127.0.0.1:3000/TopUtilizatori",
            dataType: 'json',
            credentials: "same-origin", 
            headers: {
                    'Access-Control-Allow-Origin': '*',
                  },
            success: function(data) {
                var dataTable=[];
                var Header=['Nume utilizator', 'Numar de sesizari trimise'];
       
                dataTable.push(Header);
                for (var i=0; i<data.length; i++) {
                  var temp=[];
                  temp.push(data[i]._id.email);
                  temp.push(data[i].count);
                  dataTable.push(temp);
                }   
                var chartData = google.visualization.arrayToDataTable(dataTable);
                var btnSave = document.getElementById('save-pdf');
              
              

                var options = {
                    title: "Top utilizatori în funcție de numărul de sesizări trimise",
                    width: 600,
                    height: 400,
                    bar: {groupWidth: "95%"},
                    legend: { position: "none" },
                };
                var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
                google.visualization.events.addListener(chart, 'ready', function () {
                    btnSave.disabled = false;
                  });
                
                  btnSave.addEventListener('click', function () {
                    var doc = new jsPDF();
                    doc.addImage(chart.getImageURI(), 0, 0);
                    doc.save('chart.pdf');
                  }, false);
                 
                chart.draw(chartData, options);
            },
            error: function() {
                alert("error");
            }
        });
    });

}
