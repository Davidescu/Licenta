$.ajax({
    url: 'http://localhost:3000/preiaUltimeleSesizari',
    dataType: 'json',
    success: function(data) {
        for (var i=0; i<data.length; i++) {
  
                var row = $('<tbody><tr><td class=\'edit\'>'+data[i].metadata.IdSesizare+
                '</td><td><br>' + data[i].metadata.email+ 
                    '</td><td><br>' + data[i].metadata.categorie + 
                    '</td><td><br>'+ data[i].metadata.street+
                    ' <br><input type="button"  onclick="ShowMaps(\'Maps'+(i+1)+'\',\''+(data[i].metadata.street)+'\')"  class="btn btn-info btn-lg" value="Vezi harta">'+ 
                    '<div id="Maps'+(i+1)+'" class=\'edit\' style="width:250px; height:250px"></div><br>'+
                        '</td><td>'+ data[i].metadata.descriere+
                        '</td><td><br>'+data[i].uploadDate+
                        '</td><td>'+'<img id="myImg'+(i+1)+'" onclick="ModalPicture(\'myImg'+(i+1)+'\')" src="http://localhost:3000/file/'+data[i].metadata.IdSesizare+'" width="120" height="120"/>'+
                        '</td><td style="color:red"><b><br>'+data[i].metadata.status+ 
                        '</td><td><br><input type="button"  onclick="Edit(\'edit'+(i+1)+'\')" class="btn btn-info btn-lg" value="Edit">'+
                            '<form id="edit'+(i+1)+'" class=\'edit\' method="POST" action="http://localhost:3000/SchimbaStatus/"><br>'+
                                '<select id="status" name="status">'+
                                    '<option name="status" value="Nerezolvat">Nerezolvat</option>'+
                                    '<option name="status" value="In curs de rezolvare">In curs de rezolvare</option>'+
                                    '<option name="status" value="Nu se poate rezolva">Nu se poate rezolva</option>'+
                                    '<option name="status" value="Rezolvat">Rezolvat</option>'+
                                  '</select><br>'+
                                  '<div class="form-group">'+
                                      '<input type="hidden" name="_id" id="edt" value="'+data[i].metadata.IdSesizare+'">'+
                                  '</div>'+
                                  '<br style="clear:both">'+
                                  '<div class="form-group">'+
                                    '<input type="hidden" class="form-control" id="email" name="email" value="'+data[i].metadata.email+'" required>'+
                                  '</div>'+
                                  '<div class="form-group">'+
                                    '<input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" value="Sesizare Civic Alert Iasi" required>'+
                                  '</div>'+
                                  '<div class="form-group">'+
                                    '<textarea class="form-control" type="textarea" id="message" name="message" placeholder="Message" maxlength="75" rows="2" required></textarea>'+
                                  '</div>'+
                                  '<div class="text-center">'+
                                    '<button type="submit" id="submit" name="submit" class="btn btn-primary pull-right btn-submit">Trimite</button>'+
                                  '</div>'+
                          '</form>'+
                        '</td></tr></tbody>');
                        
                $('#myTableNewsSesizare').append(row);
               
                
               
                
             
        }
       
    },
    error: function(jqXHR, textStatus, errorThrown){
        alert('Error: ' + textStatus + ' - ' + errorThrown);
    }
});
function Edit(id){
    var ed=document.getElementById(id);
    if(ed.style.display==="none"){
      ed.style.display="block";
    }else{
      ed.style.display="none";
    }
  }
  
 
  
  function ModalPicture(img){
      var modal = document.getElementById('myModalPicture');
      var i = document.getElementById(img);
      var modalImg = document.getElementById("img01");
      var captionText = document.getElementById("caption");
      i.onclick = function(){
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
      };
     
      var span = document.getElementsByClassName("close")[0];
      span.onclick = function() { 
        modal.style.display = "none";
      }
  
    }
/*cautare in tabel dupa email*/
    function searchTable(){
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTableNewsSesizare");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
          td = tr[i].getElementsByTagName("td")[1];
          if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
              tr[i].style.display = "";
            } else {
              tr[i].style.display = "none";
            }
          }       
        }
    }
    /*functie pentru menu*/
    $(document).ready(function () {
      $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
        $(this).toggleClass('active');
      });
    });

    function cautareDupaCategorie() {
  
      let dropdown, table, rows, cells, categorie, filter;
      dropdown = document.getElementById("categorieDropdown");
      table = document.getElementById("myTableNewsSesizare");
      rows = table.getElementsByTagName("tr");
      filter = dropdown.value;
    
      for (let row of rows) 
      { 
        cells = row.getElementsByTagName("td");
        categorie = cells[2] || null;
        if (filter === "All" || !categorie || (filter === categorie.textContent)) {
          row.style.display = ""; 
        }
        else {
          row.style.display = "none"; 
        }
      }
    }
    
  