
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);
        google.charts.setOnLoadCallback(drawStreetChart);
      

      function drawChart() {
        $(document).ready(function(){
          $.ajax({
            url: "http://127.0.0.1:3000/NrOfCategory",
            dataType: 'json',
            credentials: "same-origin", //include, same-origin
            headers: {
                    'Access-Control-Allow-Origin': '*',
                  },
            success: function(data) {
              
              var dataTable=[];
              var Header=['Categorii','Sesizari trimise'];
              dataTable.push(Header);
              for (var i=0; i<data.length; i++) {
                var temp=[];
                temp.push(data[i]._id.categorie);
                temp.push(data[i].count);
                dataTable.push(temp);
              }   
              var chartData = google.visualization.arrayToDataTable(dataTable);
              var btnSave = document.getElementById('save-pdf');

              var options = {
                 title: 'Categorii'
              };

              var chart = new google.visualization.PieChart(document.getElementById('piechart'));

              google.visualization.events.addListener(chart, 'ready', function () {
                btnSave.disabled = false;
              });
            
              btnSave.addEventListener('click', function () {
                var doc = new jsPDF();
                doc.addImage(chart.getImageURI(), 0, 0);
                doc.save('chart.pdf');
              }, false);
             
              chart.draw(chartData, options);
              
            },
            error: function() {
              alert("error");
            }
          });        
        });

      }


      function drawStreetChart() {
        $(document).ready(function(){
          $.ajax({
            url: "http://127.0.0.1:3000/NumarLocatie",
            dataType: 'json',
            credentials: "same-origin", 
            headers: {
                    'Access-Control-Allow-Origin': '*',
                  },
            success: function(data) {
              
              var dataTable=[];
              var Header=['Locații','Sesizari trimise'];
              dataTable.push(Header);
              for (var i=0; i<data.length; i++) {
                var temp=[];
                temp.push(data[i]._id.adresa);
                temp.push(data[i].count);
                dataTable.push(temp);
              }   
              var chartData = google.visualization.arrayToDataTable(dataTable);
              var btnSave = document.getElementById('save-pdf');

              var options = {
                 title: 'Locații'
              };

              var chart = new google.visualization.PieChart(document.getElementById('piechartLocation'));

              google.visualization.events.addListener(chart, 'ready', function () {
                btnSave.disabled = false;
              });
            
              btnSave.addEventListener('click', function () {
                var doc = new jsPDF();
                doc.addImage(chart.getImageURI(), 0, 0);
                doc.save('chart.pdf');
              }, false);
             
              chart.draw(chartData, options);
              
            },
            error: function() {
              alert("error");
            }
          });        
        });

      }
    

      $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
          $('#sidebar').toggleClass('active');
          $(this).toggleClass('active');
        });
      });
