const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');
const multer = require('multer');
const GridFsStorage = require('multer-gridfs-storage');
const Grid = require('gridfs-stream');
const nodeMailer=require('nodemailer');
const AutoIncrement=require('mongodb-autoincrement');
mongoose.plugin(AutoIncrement.mongoosePlugin);
const checkAuth=require('../check-auth.js');
let gfs;

module.exports=app=>{
 
const url = 'mongodb://localhost:27017/Sesizari_Database';
const conn = mongoose.createConnection(url);

conn.once('open', () => {
  
  gfs = Grid(conn.db, mongoose.mongo);
  gfs.collection('uploads');
});


let storage = new GridFsStorage({
  url: url,
  file: (req, file) => {
    return new Promise((resolve, reject) => {
      gfs.files.count({}, function(err, count) {
        amount_documents = count+1;
        const post_data=req.body;
        const email=post_data.email;
        const categorie=post_data.categorie;
        const street=post_data.street;
        const descriere=post_data.descriere;
        const status=post_data.status;
       
        const filename = file.originalname; 
        const fileInfo = {
          filename: filename,  //numele imaginii
          bucketName: 'uploads', //Numele colectiei
          metadata:{
                IdSesizare:amount_documents.toString(),
                email:email,
                categorie:categorie,
                street:street,
                descriere:descriere,
                status:status,
    
              }

        };
       
     
        resolve(fileInfo);
      });
      
       
     
    });
  }
});

let upload=multer({storage:storage}).array('upload',3);


/*incarcarea sesizării in baza de date*/
app.post('/upload',checkAuth,function(req,res){
  
  upload(req,res,function(err){
    if(err){
      res.json({error_code:1,err_desc:err});
      return;
    }
    res.json({error_code:0,err_desc:null});
   
  });
});



/*vizualizarea imaginilor in functie de id*/
app.get('/file/:IdSesizare', (req, res) => {
  gfs.collection('uploads'); 

  /*verficam daca exista inregistrarea cu id-ul respectiv*/
  gfs.files.find({'metadata.IdSesizare': req.params.IdSesizare}).toArray(function(err, files){
      if(!files || files.length === 0){
          return res.status(404).json({
              responseCode: 1,
              responseMessage: "error"
          });
      }
      var readstream;
     
      readstream = gfs.createReadStream({
          filename: files[0].filename
      });
      return readstream.pipe(res);
  });
});




/*Vizualizarea sesizarilor in functie de email si status*/
  app.get('/Sesizare/:email/:status',checkAuth, (req,res) => {
    gfs.files.aggregate([{$match:{'metadata.email':req.params.email,'metadata.status':req.params.status}},{$project:{_id:0,uploadDate:{$substr:["$uploadDate",0,10]},'metadata.email':1,'metadata.categorie':1,'metadata.street':1,'metadata.descriere':1,'metadata.status':1}}]).toArray((err, result) => {
      if (err) return console.log(err);
    res.send(result);
    console.log("get ok");

  });
});

/*vizualizarea tuturor sesizarilor */
app.get('/GetSesizari', (req,res) => {
  gfs.files.aggregate([{$project:{_id:0,uploadDate:{$substr:["$uploadDate",0,10]},'metadata.IdSesizare':1,'metadata.email':1,'metadata.categorie':1,'metadata.street':1,'metadata.descriere':1,'metadata.status':1}}]).toArray((err, result) => {
    if (err) return console.log(err);
    res.send(result);

  });
});
/*vizualizarea sesizarilor in functie de status*/
app.get('/GetSesizare/:status',(req,res)=>{
  gfs.files.aggregate([{$project:{_id:0,uploadDate:{$substr:["$uploadDate",0,10]},'metadata.IdSesizare':1,'metadata.email':1,'metadata.categorie':1,'metadata.street':1,'metadata.descriere':1,'metadata.status':1}},{$match:{"metadata.status":req.params.status}}]).toArray((err,result)=>{
    if (err) return console.log(err);
    res.send(result);
  });
});


/*Numarul de sesizari rezolvate in functie de email*/
app.get('/GetStatus1/:email',checkAuth, (req,res) => {
  gfs.files.find({'metadata.email':req.params.email,'metadata.status':'Rezolvat'}).count({}, function(error, nr){
    if (error) throw error;
    count = nr;
    res.json(count);
  });
});
/*Numarul de sesizari rezolvate*/
app.get('/sesizariRezolvate', (req,res) => {
  gfs.files.find({'metadata.status':'Rezolvat'}).count({}, function(error, nr){
    if (error) throw error;
    count = nr;
    res.json({"Numar": count});
  });
});

/*Numarul de inregistrari pentru fiecare categorie in parte*/
app.get('/NrOfCategory',(req,res)=>{
  gfs.files.aggregate([{$group:{_id:{categorie:'$metadata.categorie'},count:{$sum:1}}}]).toArray((err,result)=>{
    res.send(result);
  });
});

/*Numarul de sesizari pt fiecare categorie in functie de statusul acesteia*/
app.get('/NrOfCategoryByStatus/:status',(req,res)=>{
  gfs.files.aggregate([{$match:{"metadata.status":req.params.status}},{$group:{_id:{categorie:'$metadata.categorie',status:'$metadata.status'},count:{$sum:1}}}]).toArray((err,result)=>{
    res.send(result);
  });
});

/*Numarul de sesizari trimise din fiecare adresa*/
app.get('/NumarLocatie',(req,res)=>{
  gfs.files.aggregate([{$group:{_id:{adresa:'$metadata.street'},count:{$sum:1}}}]).toArray((err,result)=>{
    res.send(result);
  });
});





/*Nr de sesizari nerezolvate*/
app.get('/sesizariNerezolvate', (req,res) => {
  gfs.files.find({$or:[{'metadata.status':'Nerezolvat'},{'metadata.status':'In curs de rezolvare'},{'metadata.status':'trimis'},{'metadata.status':'Nu se poate rezolva'}]}).count({}, function(error, nr){
    if (error) throw error;
    count = nr;
    res.json({"Numar": count});
  });
});

/*Numarul de sesizari trimise de fiecare user*/
app.get('/NrOfSesizare/:email',checkAuth, (req, res) => {
  gfs.files.find({'metadata.email':req.params.email}).count({}, function(error, nr){
    if (error) throw error;
    count = nr;
    console.log("count is : " + count);
    res.json(count);
  
  })
});

/** Numar de sesizari trimise in total*/
app.get('/nrSesizari' ,function(req,res){
  gfs.files.count({}, function(error, numOfDocs){
    if (error) throw error;
    count = numOfDocs;
    console.log("count is : " + count);
    res.json(count);

  });
});

/*Schimba statusul sesizarii, si trimite mail utilizatorului cu statusul actual.*/
app.post('/SchimbaStatus',(request,res)=>{
  const post_data=request.body;
  const _id=post_data._id;
  const status=post_data.status;
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  const transporter=nodeMailer.createTransport({
    service:'gmail',
    auth:{
      user:'dumitru.daniel.davidescu@gmail.com',
      pass:'Daviddany18'
    }
  
  
    });
    const mailOption={
    from:'dumitru.daniel.davidescu@gmail.com',
    to:post_data.email,
    subject:post_data.subject,
    html:`Buna ziua. Statusul sesizării dumneavoastră a fost schimbat în "${post_data.status}". 
    Observații:${post_data.message}`
    };
    transporter.sendMail(mailOption,(error,info)=>{
    if(error){
      return console.log(error);
    }
    console.log('Message %s send: %s',info.messageId,info.response);
    });
    gfs.files.update({'metadata.IdSesizare':_id},{$set:{'metadata.status':status}})
		.then(result=>{
			console.log("OK");
			res.redirect('/sesizari');

			
		})
		.catch(err=>res.status(err.status).json({message:err.message}));
  
});

/*Preia toate sesizarile trimise de utilizatori in ultimele 24 de ore*/
app.get('/preiaUltimeleSesizari',(request,res)=>{
  gfs.files.find({"uploadDate":{'$lt':new Date(),'$gte':new Date(new Date().setDate(new Date().getDate()-1))},"metadata.status":"trimis"},{$project:{_id:0,uploadDate:1,'metadata.IdSesizare':1,'metadata.email':1,'metadata.categorie':1,'metadata.street':1,'metadata.descriere':1,'metadata.status':1}}).toArray((err,result)=>{
    if (err) return console.log(err);
    res.send(result);
  })
  
});
/*Preia toate sesizarile trimise de utilizatori in ultimele 24 de ore*/
app.get('/getLastComplaint',checkAuth,(request,res)=>{
  gfs.files.aggregate([{$match:{"uploadDate":{'$lt':new Date(),'$gte':new Date(new Date().setDate(new Date().getDate()-1))}}},{$project:{_id:0,uploadDate:{$substr:["$uploadDate",0,10]},'metadata.IdSesizare':1,'metadata.email':1,'metadata.categorie':1,'metadata.street':1,'metadata.descriere':1,'metadata.status':1}}]).toArray((err,result)=>{
    if (err) return console.log(err);
    res.send(result);
  })
  
});


/*Numarul de sesizari pentru fiecare email in parte*/
app.get('/TopUtilizatori/',(req,res) => {
  gfs.files.aggregate([{$group:{_id:{email:'$metadata.email'},count:{$sum:1}}}]).toArray((err,result)=>{
    res.send(result);
  });
});

}


